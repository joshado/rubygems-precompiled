module Compiled
  module Gem
    VERSION = "0.0.1"
  end
end
