require "compiled/gem/version"

module Compiled
  module Gem
    # Your code goes here...
  end
end
