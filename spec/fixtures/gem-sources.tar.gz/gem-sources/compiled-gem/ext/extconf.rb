require 'mkmf'

create_makefile('test_ext/test_ext')

