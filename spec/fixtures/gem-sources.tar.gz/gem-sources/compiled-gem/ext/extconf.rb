require 'mkmf'

STDERR.print "build-args #{ARGV.join(" ")}\n"
STDERR.flush
create_makefile('test_ext/test_ext')

