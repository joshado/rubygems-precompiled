#include <ruby.h>

VALUE TheClass = Qnil;

void Init_test_ext();

VALUE module_function(void);

void Init_test_ext() {
  TheClass = rb_define_class("CompiledClass",rb_cObject);
  rb_define_method(TheClass, "test_method", module_function, 0);
}

VALUE module_function(void) {
  char* string = "Hello, world!\n";

  return rb_str_new(string,strlen(string));
}

