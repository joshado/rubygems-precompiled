require "simple/gem/version"

module Simple
  module Gem
    # Your code goes here...
  end
end
